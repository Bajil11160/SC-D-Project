from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import os
import calendar
from datetime import datetime

# ----------------------------
app = Flask(__name__)
app.secret_key = "352022130-key"  # Change this to something random and secret
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///promanager.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# ----------------------------
# Models
# ----------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    due_date = db.Column(db.String(50), nullable=True)
    category = db.Column(db.String(50), nullable=True)
    priority = db.Column(db.String(20), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

# ----------------------------
# Middleware - Before Request
# ----------------------------
@app.before_request
def load_user():
    user_id = session.get("user_id")
    g.user = User.query.get(user_id) if user_id else None

# ----------------------------
# Routes
# ----------------------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists.')
            return redirect(url_for('register'))

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! You can now log in.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password_input = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password_input):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Login successful!')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if not g.user:
        flash("Please log in.")
        return redirect(url_for("login"))
    
    user_tasks = Task.query.filter_by(user_id=g.user.id).all()
    return render_template("dashboard.html", tasks=user_tasks)

@app.route('/calendar')
def calendar_view():
    if not g.user:
        flash("Please log in.")
        return redirect(url_for("login"))

    year = int(request.args.get('year', datetime.today().year))
    month = int(request.args.get('month', datetime.today().month))
    category_filter = request.args.get('category')
    priority_filter = request.args.get('priority')

    if month < 1:
        month = 12
        year -= 1
    elif month > 12:
        month = 1
        year += 1

    query = Task.query.filter_by(user_id=g.user.id)
    if category_filter:
        query = query.filter(Task.category == category_filter)
    if priority_filter:
        query = query.filter(Task.priority == priority_filter)

    tasks = query.all()

    task_map = {}
    for task in tasks:
        try:
            date_obj = datetime.strptime(task.due_date, "%Y-%m-%d")
            if date_obj.year == year and date_obj.month == month:
                task_map.setdefault(date_obj.day, []).append(task)
        except:
            continue

    categories = db.session.query(Task.category).filter_by(user_id=g.user.id).distinct().all()

    return render_template(
        "calendar_view.html",
        year=year, month=month,
        month_name=calendar.month_name[month],
        days=list(calendar.Calendar().itermonthdays(year, month)),
        task_map=task_map,
        categories=[c[0] for c in categories],
        selected_category=category_filter,
        selected_priority=priority_filter
    )

@app.route('/save-task', methods=["POST"])
def save_task():
    task_id = request.form.get("task_id")
    title = request.form["title"]
    description = request.form["description"]
    category = request.form["category"]
    priority = request.form["priority"]
    due_date = request.form["due_date"]

    if task_id:
        task = Task.query.get(task_id)
        if task and task.user_id == g.user.id:
            task.title = title
            task.description = description
            task.category = category
            task.priority = priority
            task.due_date = due_date
            db.session.commit()
    else:
        new_task = Task(
            title=title,
            description=description,
            category=category,
            priority=priority,
            due_date=due_date,
            user_id=g.user.id
        )
        db.session.add(new_task)
        db.session.commit()

    return redirect(url_for("calendar_view"))

@app.route('/add-task', methods=['GET', 'POST'])
def add_task():
    if not g.user:
        flash("Please log in to add a task.")
        return redirect(url_for("login"))

    if request.method == 'POST':
        new_task = Task(
            title=request.form['title'],
            description=request.form['description'],
            due_date=request.form['due_date'],
            category=request.form['category'],
            priority=request.form['priority'],
            user_id=g.user.id
        )
        db.session.add(new_task)
        db.session.commit()
        flash("Task added successfully!")
        return redirect(url_for('dashboard'))

    return render_template("add_task.html")

@app.route('/delete-task/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    if not g.user:
        flash("Please log in.")
        return redirect(url_for("login"))
    
    task = Task.query.get(task_id)
    if task and task.user_id == g.user.id:
        db.session.delete(task)
        db.session.commit()
        flash("Task deleted.")
    return redirect(url_for("dashboard"))

@app.route('/edit-task/<int:task_id>', methods=['GET', 'POST'])
def edit_task(task_id):
    if not g.user:
        flash("Please log in.")
        return redirect(url_for("login"))
    
    task = Task.query.get(task_id)
    if task.user_id != g.user.id:
        flash("Unauthorized access.")
        return redirect(url_for("dashboard"))

    if request.method == 'POST':
        task.title = request.form['title']
        task.description = request.form['description']
        task.due_date = request.form['due_date']
        task.category = request.form['category']
        task.priority = request.form['priority']
        
        db.session.commit()
        flash("Task updated successfully!")
        return redirect(url_for('dashboard'))

    return render_template('edit_task.html', task=task)

@app.route('/notes', methods=["GET", "POST"])
def notes():
    user_id = session['user_id']
    user = User.query.get(user_id)
    if request.method == "POST":
        title = request.form['title']
        content = request.form['content']
        note = Note(title=title, content=content, user_id=user_id)
        db.session.add(note)
        db.session.commit()
        return redirect(url_for('notes'))

    user_notes = Note.query.filter_by(user_id=user_id).all()
    return render_template('notes.html', notes=user_notes, user=user)


@app.route('/delete-note/<int:note_id>', methods=["POST"])
def delete_note(note_id):
    note = Note.query.get_or_404(note_id)
    if note.user_id != g.user.id:
        flash("Unauthorized access.")
        return redirect(url_for("notes"))

    db.session.delete(note)
    db.session.commit()
    flash("Note deleted.")
    return redirect(url_for("notes"))

@app.route('/edit-note/<int:note_id>', methods=['GET', 'POST'])
def edit_note(note_id):
    if not g.user:
        flash("Please log in.")
        return redirect(url_for("login"))

    note = Note.query.get_or_404(note_id)

    if note.user_id != g.user.id:
        flash("Unauthorized access.")
        return redirect(url_for("notes"))

    if request.method == 'POST':
        note.title = request.form['title']
        note.content = request.form['content']
        db.session.commit()
        flash("Note updated successfully!")
        return redirect(url_for('notes'))

    return render_template('edit_note.html', note=note)

@app.route('/toggle-theme', methods=['POST'])
def toggle_theme():
    current = session.get('theme', 'light')
    session['theme'] = 'dark' if current == 'light' else 'light'
    return redirect(request.referrer or url_for('dashboard'))

# ----------------------------
# Run App
# ----------------------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
